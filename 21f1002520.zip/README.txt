WELCOME TO QUANTIFIED SELF

-----------------------------------------------------------------------------------------------------------------------
To run this application type ----> python main.py or Flask.run both works fine 